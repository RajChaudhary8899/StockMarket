﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Data
{
    public class MarketPriceUpdateModel
    {
        public int SymbolId { get; set; }
        public char OpertaionforPrice { get; set; }
    }
}
